let carta = ""
let opciones = ""
let platos = ""
let cuentaParcial = 0
let cuentaTotal = 0
let comida =""
let pedido=[]
function iniciar(){
    cartaResto()
}

class burritos{
    constructor (id, tipo, variedad, precio){ 
        this.id=id
        this.tipo=tipo
        this.variedad=variedad
        this.precio=precio
    }
}
class tacos{
    constructor (id, tipo, variedad, precio){ 
        this.id=id
        this.tipo=tipo
        this.variedad=variedad
        this.precio=precio
    }
}
class postres{
    constructor (id, tipo, variedad, precio){ 
        this.id=id
        this.tipo=tipo
        this.variedad=variedad
        this.precio=precio
    }
}
class bebidas{
    constructor (id, tipo, variedad, precio){ 
        this.id=id
        this.tipo=tipo
        this.variedad=variedad
        this.precio=precio
    }
}
const burritoCarne = new burritos(1,"Burrito","Carne","$650")
const burritoCerdo = new burritos(2,"Burrito","Cerdo","$570")
const burritoPollo = new burritos(3,"Burrito","Pollo","$500")
const burritoVeggie = new burritos(4,"Burrito","Veggie","$520")
const tacoPastor = new tacos(5,"Taco","Pastor","$580")
const tacoCerdo = new tacos(6,"Taco","Cerdo","$550")
const tacoMixto = new tacos(7,"Taco","Pollo y Carne","$500")
const tacoVeggie = new tacos(8,"Taco","Veggie","$400")
const postreBanana = new postres(9,"Postre", "Banana con tequila","$350")
const postreBrownie = new postres(10,"Postre","Brownie con helado","$430")
const postreHelado = new postres(11,"Postre","Helado de Dulce de leche","$350")
const postreVolcan = new postres(12,"Postre","Volcan de chocolate","$450")
const bebidaCoca = new bebidas(13,"Bebida","Coca-Cola","$150")
const bebidaTrago = new bebidas(14,"Bebida","Margarita","$300")
burritos=[]
burritos.push(burritoCarne,burritoCerdo,burritoPollo,burritoVeggie)
tacos=[]
tacos.push(tacoPastor,tacoCerdo,tacoMixto,tacoVeggie)
postres=[]
postres.push(postreBanana,postreBrownie,postreHelado,postreVolcan)
bebidas=[]
bebidas.push(bebidaCoca,bebidaTrago)
function cartaResto(){
    alert("Bienvenido a Don Papi")
    carta = prompt("Desea ver la carta?")
    while (carta.toLowerCase() === "si"){
        mostrarCarta()
        while (opciones.toLowerCase() === "tacos" || opciones.toLowerCase() === "burritos" || opciones.toLowerCase() === "postres" || opciones.toLowerCase() === "bebidas"){
            if (opciones.toLowerCase() === "tacos"){
                alert("Seleccione alguna de las siguientes variedades por el numero")
                for(const elem of tacos)
                alert(elem.id + ") " + elem.variedad + " " + elem.precio)
                platos = prompt("Ingrese el numero de su variedad: ")
                if (platos == "5"){
                    cuentaParcial += 580
                    pedido.push(tacoPastor)
                    console.log("Su cuenta parcial es: $" + cuentaParcial)
                    console.log(pedido)
                    pedirComida()
                    if (carta=="no"){
                        break
                    }
                    }
                else if (platos == "6"){
                    cuentaParcial += 550
                    pedido.push(tacoCerdo)
                    console.log("Su cuenta parcial es: $" + cuentaParcial)
                    console.log(pedido)
                    pedirComida()
                }
                else if (platos == "7"){
                    cuentaParcial += 500
                    pedido.push(tacoMixto)
                    console.log("Su cuenta parcial es: " + cuentaParcial)
                    console.log(pedido)
                    pedirComida()
                }
                else if (platos == "8"){
                    cuentaParcial += 400
                    pedido.push(tacoVeggie)
                    console.log("Su cuenta parcial es: " + cuentaParcial)
                    console.log(pedido)
                    pedirComida()
                }
            }
            else if (opciones.toLowerCase() === "burritos"){ 
                alert("Seleccione alguna de las siguientes variedades por el numero")
                for(const elem of burritos)
                alert(elem.id + ") " + elem.variedad + " " + elem.precio)
                platos = prompt("Ingrese el numero de su variedad: ")
                if (platos=="1"){
                    cuentaParcial += 650
                    pedido.push(burritoCarne)
                    console.log("Su cuenta parcial es: " + cuentaParcial)
                    console.log(pedido)
                    pedirComida()
                }
                else if (platos=="2"){
                    cuentaParcial += 570
                    pedido.push(burritoCerdo)
                    console.log("Su cuenta parcial es: " + cuentaParcial)
                    console.log(pedido)
                    pedirComida()
                }
                else if (platos=="3"){
                    cuentaParcial += 500
                    pedido.push(burritoPollo)
                    console.log("Su cuenta parcial es: " + cuentaParcial)
                    console.log(pedido)
                    pedirComida()
                }
                else if (platos=="4"){
                    cuentaParcial += 520
                    pedido.push(burritoVeggie)
                    console.log("Su cuenta parcial es: " + cuentaParcial)
                    console.log(pedido)
                    pedirComida()
                }
                }
            else if (opciones.toLowerCase() === "postres"){ 
                alert("Seleccione alguna de las siguientes variedades por el numero")
                for(const elem of postres)
                alert(elem.id + ") " + elem.variedad + " " + elem.precio)
                platos = prompt("Ingrese el numero de su variedad: ")
                if (platos=="9"){
                    cuentaParcial+=350
                    pedido.push(postreBanana)
                    console.log("Su cuenta parcial es: " + cuentaParcial)
                    console.log(pedido)
                    pedirComida()
                }
                else if(platos=="10"){
                    cuentaParcial+=430
                    pedido.push(postreBrownie)
                    console.log("Su cuenta parcial es: " + cuentaParcial)
                    console.log(pedido)
                    pedirComida()
                }
                else if(platos=="11"){
                    cuentaParcial+=350
                    pedido.push(postreHelado)
                    console.log("Su cuenta parcial es: " + cuentaParcial)
                    console.log(pedido)
                    pedirComida()
                }
                else if(platos=="12"){
                    cuentaParcial+=450
                    pedido.push(postreVolcan)
                    console.log("Su cuenta parcial es: " + cuentaParcial)
                    console.log(pedido)
                    pedirComida()
                }
                }
            else if (opciones.toLowerCase() === "bebidas"){ 
                alert("Seleccione alguna de las siguientes variedades por el numero")
                for(const elem of bebidas)
                alert(elem.id + ") " + elem.variedad + " " + elem.precio)
                platos = prompt("Ingrese el numero de su variedad: ")
                if (platos=="13"){
                    cuentaParcial+=350
                    pedido.push(bebidaCoca)
                    console.log("Su cuenta parcial es: " + cuentaParcial)
                    console.log(pedido)
                    pedirComida()
                }
                else if(platos=="14"){
                    cuentaParcial+=300
                    pedido.push(bebidaTrago)
                    console.log("Su cuenta parcial es: " + cuentaParcial)
                    console.log(pedido)
                    pedirComida()
                }
                }
            else{
                alert("Opcion incorrecta! Intente de nuevo")
                opciones = prompt(`
                    MENÚ\n
                    TACOS\n
                    BURRITOS\n,
                    POSTRES\n
                    BEBIDAS\n `
                )
            }
        }
        if (opciones.toLowerCase() !== "tacos" || opciones.toLowerCase() !== "burritos" || opciones.toLowerCase() !== "postres" || opciones.toLowerCase() !== "bebidas"){
            console.log(opciones)
            alert("OPCION INCORRECTA, INTENTE DE NUEVO")
            opciones = prompt(`MENÚ\n
                TACOS\n
                BURRITOS\n,
                POSTRES\n
                BEBIDAS\n `
                )
        }
    } 
    if (carta.toLowerCase() === "no"){
        alert("Gracias por visitarnos!")
    }   
    }

function mostrarCarta(){
    opciones = prompt(`MENÚ\n
        TACOS\n
        BURRITOS\n
        POSTRES\n
        BEBIDAS\n `)
}
function pedirComida(){
    comida = prompt ("Desea seguir pidiendo comida?")
                    if (comida.toLowerCase() === "si"){
                        mostrarCarta()}
                    else {
                        cuentaTotal = cuentaParcial
                        for(let i = 0; i<pedido.length;i++){
                            alert("El total de su pedido es de: $" + cuentaTotal)
                            alert("Su pedido es: " + pedido[i])
                        }
                        carta="no"
                        
                    }
}
 iniciar()